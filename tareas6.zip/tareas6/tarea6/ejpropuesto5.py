n = 6
suma = 0
for i in range(1, n + 1):
    if i % 2 == 0:
        suma -= i
    else: 
        suma += i
print(f"Resultado de la expresion: {suma}")