n = int(input("Ingrese cantidad de elementos: "))

i = 1

while i <= n:
    print(f"{i}/2", end="")

    if i < n:
        print(" + ", end="")

    i += 1