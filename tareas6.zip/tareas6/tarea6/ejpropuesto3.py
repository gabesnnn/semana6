n = 3 
suma = 0
for i in range(n):
    termino = 2 ** i
    suma += termino
    print(f"2^{i} = {termino}")
print(f"Suma total: {suma}")