n = 3
suma = 0
for i in range(1, n + 1):
    num = 2 * i - 1
    den = 2 * i
    termino = num / den
    suma += termino
    print(f"T{i}: {num}/{den} = {termino:.2f}")
print(f"Suma total: {suma:.2f}")