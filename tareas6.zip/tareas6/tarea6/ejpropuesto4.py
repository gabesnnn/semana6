n = 4
suma = 0
for i in range (1, n + 1):
    suma += 2 ** i
print(f"La sumatoria de 2^1 hasta 2^{n} es: {suma}")