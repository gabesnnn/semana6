# Entrada de datos
saldo = float(input("Depósito inicial: S/ "))
meta = float(input("Meta a alcanzar: S/ "))

# Variables
tasa = 0.015  # 1.5%
meses = 0

print(f"\nMes 0: S/ {saldo:.2f}")

# Proceso
while saldo < meta:
    saldo = saldo * (1 + tasa)
    meses += 1

    print(f"Mes {meses}: S/ {saldo:.2f}")

# Resultado final
print(f"\nAlcanzará la meta en {meses} meses.")