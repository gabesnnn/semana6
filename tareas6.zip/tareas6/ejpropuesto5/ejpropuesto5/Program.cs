﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejpropuesto5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 8;
            int suma = 0;
            for (int i = 1; i <= n; i++)
            {
                if (1 % 2 == 0)
                {
                    suma -= i;
                }
                else
                {
                    suma += i;
                }
            }
            Console.WriteLine($"Resultado de la expresion: {suma}");
            Console.ReadKey();
        }
    }
}
