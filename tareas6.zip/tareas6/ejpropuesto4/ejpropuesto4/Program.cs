﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejpropuesto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 4;
            double suma = 0;
            for (int i = 1; i <= n; i++)
            {
                suma += Math.Pow(2, i);
            }
            Console.WriteLine($"La sumatoria de 2^1 hasta 2^{n} es: {suma}");
            Console.ReadKey();


        }
    }
}
