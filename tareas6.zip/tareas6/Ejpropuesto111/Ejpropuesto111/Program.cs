﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejpropuesto111
{
    internal class Program
    {
        static void Main(string[] args)
        {
			int n, i = 1;

			Console.Write("Ingrese cantidad de elementos: ");
			n = int.Parse(Console.ReadLine());

			while (i <= n)
			{
				Console.Write(i + "/2");

				if (i < n)
				{
					Console.Write(" + ");
				}

				i++;
			}

			Console.ReadKey();
		}
    }
}
