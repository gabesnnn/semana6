﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio5
{
    internal class Program
    {
        static void Main(string[] args)
		{ 
			Console.Write("Depósito inicial: S/ ");
			double saldo = Convert.ToDouble(Console.ReadLine());

			Console.Write("Meta a alcanzar: S/ ");
			double meta = Convert.ToDouble(Console.ReadLine());

			
			double tasa = 0.015; // 1.5%
			int meses = 0;

			Console.WriteLine("\nMes 0: S/ " + saldo.ToString("F2"));

			
			while (saldo < meta)
			{
				saldo = saldo * (1 + tasa);
				meses++;

				Console.WriteLine("Mes " + meses + ": S/ " + saldo.ToString("F2"));
			}

			
			Console.WriteLine("\nAlcanzará la meta en " + meses + " meses.");
			Console.ReadKey();
		}
    }
}
