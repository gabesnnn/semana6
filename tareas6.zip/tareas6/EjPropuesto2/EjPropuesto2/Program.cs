﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjPropuesto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 3;
            double suma = 0;
            for (int i = 1; i <= n; i++)
            {
                int num = 2 * i - 1;
                int den = 2 * i;
                double termino = (double)num / den;
                suma += termino;
                Console.WriteLine($"T{i}: {num}/{den} = {termino:F2}");
            }
            Console.WriteLine($"Suma total: {suma:F2}");
            Console.ReadKey();
        }
    }
}
