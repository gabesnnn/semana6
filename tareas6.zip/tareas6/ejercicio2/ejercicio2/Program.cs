﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
			double suma = 0;
			int contador = 0;
			double mayor = 0;

			double menor = double.MaxValue;

			Console.Write("Ingrese nota (-1 para terminar): ");
			double nota = double.Parse(Console.ReadLine());

			while (nota != -1)
			{
				// Validar rango
				if (nota < 0 || nota > 20)
				{
					Console.WriteLine("Nota inválida. Debe estar entre 0 y 20.");
				}
				else
				{
					// Acumular
					suma = suma + nota;
					contador = contador + 1;

					// Nota mayor
					if (nota > mayor)
					{
						mayor = nota;
					}

					// Nota menor
					if (nota < menor)
					{
						menor = nota;
					}
				}

				Console.Write("Ingrese nota (-1 para terminar): ");
				nota = double.Parse(Console.ReadLine());
			}

			// Verificar si hubo notas válidas
			if (contador > 0)
			{
				double promedio = suma / contador;

				Console.WriteLine("---- RESULTADOS ----");
				Console.WriteLine($"Promedio: {promedio:F2}");
				Console.WriteLine($"Nota mayor: {mayor}");
				Console.WriteLine($"Nota menor: {menor}");
				Console.WriteLine($"Notas válidas: {contador}");
			}
			else
			{
				Console.WriteLine("No se ingresaron notas válidas.");
			}

			Console.ReadKey();
		}
    }
}
